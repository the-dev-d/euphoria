import{s}from"../chunks/scheduler._6DmXkuH.js";import{S as t,i as e}from"../chunks/index.BYXNZXlm.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
