import{a as t}from"../chunks/entry.3ADNXllK.js";export{t as start};
