import{a as t}from"../chunks/entry.BAKMHLdN.js";export{t as start};
