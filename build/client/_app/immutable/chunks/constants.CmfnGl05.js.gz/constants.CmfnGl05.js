const e={codingUG:150,codingPG:150,webDesigning:150,treasureHunt:600,respawn:700,battle:129};export{e as P};
